using UnityEngine;

public interface IWeaponCategorised
{
    WeaponCategory Category { get; }
}