public interface ISpecialAbility
{
    /// Return true if the ability actually fired.
    bool Activate();
}