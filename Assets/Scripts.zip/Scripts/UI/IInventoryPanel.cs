public interface IInventoryPanel
{
    void RefreshPanel();
}