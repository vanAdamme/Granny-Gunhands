public interface IPooledRelease
{
    void Release();
}