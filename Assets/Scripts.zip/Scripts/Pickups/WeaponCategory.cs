public enum WeaponCategory
{
    Pistol,
    Shotgun,
    SMG,
    Rifle,
    Launcher,
    Special
}